/* Only one team NostalgicMen (The University of Nottingham), was able to solve this problem, we have given our solution as a sample. */

#include <cstdio>
#include <iostream>
#include <vector>
using namespace std;
#define MAXN 1002

int x[2*MAXN],y[2*MAXN];
int xx[2*MAXN],yy[2*MAXN];
int label[2*MAXN];
vector<int> edge[2*MAXN];
vector<int> redge[2*MAXN];
vector<int> f;
bool done[2*MAXN];
void dfs(int u){
	done[u] = true;
	for(int i=0;i<edge[u].size();i++) if(!done[edge[u][i]])
		dfs(edge[u][i]);
	f.push_back(u);
}
void rdfs(int u,int color){
	done[u] = true;
	label[u] = color;
	for(int i=0;i<redge[u].size();i++) if(!done[redge[u][i]])
		rdfs(redge[u][i],color);
}
int crossp(int x0,int y0,int x1,int y1,int x2,int y2){
	return x0*(y1-y2)+x1*(y2-y0)+x2*(y0-y1);
}
bool cut(int a,int b,int c,int d,int x,int y,int z,int w){
	int d1 = crossp(a,b,c,d,x,y);
	int d2 = crossp(a,b,c,d,z,w);
	int d3 = crossp(a,b,x,y,z,w);
	int d4 = crossp(c,d,x,y,z,w);
	return d1*d2<=0 && d3*d4<=0;
}
bool intersect(int i,int l,int j,int k){
	if(l+k == 1)
	return  cut(x[i],y[i],xx[i]*(1-l)+x[i]*l,y[i]*(1-l)+yy[i]*l,
		   x[j],y[j],xx[j]*(1-k)+x[j]*k,y[j]*(1-k)+yy[j]*k) ||
		cut(xx[i],yy[i],xx[i]*(1-l)+x[i]*l,y[i]*(1-l)+yy[i]*l,
		   xx[j],yy[j],xx[j]*(1-k)+x[j]*k,y[j]*(1-k)+yy[j]*k) ;

	else 
	return  cut(x[i],y[i],xx[i]*(1-l)+x[i]*l,y[i]*(1-l)+yy[i]*l,
		   xx[j],yy[j],xx[j]*(1-k)+x[j]*k,y[j]*(1-k)+yy[j]*k) ||
		cut(xx[i],yy[i],xx[i]*(1-l)+x[i]*l,y[i]*(1-l)+yy[i]*l,
		   x[j],y[j],xx[j]*(1-k)+x[j]*k,y[j]*(1-k)+yy[j]*k);
		

}
main()
{
	int n;
	int cases;
	cin>>cases;
	while(cases--){
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			scanf("%d %d %d %d",&x[i],&y[i],&xx[i],&yy[i]);
			if(y[i]>yy[i]){
				swap(x[i],xx[i]);
				swap(y[i],yy[i]);
			}
		}
		int N=2*n;
		for(int i=0;i<N;i++) {
			edge[i].clear();
			redge[i].clear();
		}
		for(int i=0;i<n;i++)
			for(int j=i+1;j<n;j++){
				for(int k=0;k<2;k++)
					for(int l=0;l<2;l++)
					{
						if(intersect(i,l,j,k)){
							edge[2*i+l].push_back(2*j+1-k);
							edge[2*j+k].push_back(2*i+1-l);
							redge[2*j+1-k].push_back(2*i+l);
							redge[2*i+1-l].push_back(2*j+k);
						}
					}
			}
		for(int i=0;i<N;i++) done[i] = false;
		f.clear();
		for(int i=0;i<N;i++) if(!done[i]) dfs(i);
		for(int i=0;i<N;i++) done[i] = false;
		int cur_label = 0;
		for(int i=f.size()-1;i>=0;i--) if(!done[f[i]]) {
			rdfs(f[i],++cur_label);
		}
		bool bad = false;
		for(int i=0;i<N;i+=2)
			if(label[i] == label[i+1]){
				bad = true;
				break;
			}
		if(bad) printf("No\n");
		else printf("Yes\n");
	}
}
