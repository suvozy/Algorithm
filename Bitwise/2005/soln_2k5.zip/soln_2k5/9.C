/* Only one team NostalgicMen (The University of Nottingham), was able to solve this problem, we have given our solution as a sample. */

#include <cstdio>
#include <iostream>
#include <vector>
#include <set>
#include <queue>
using namespace std;
#define MAXN 1002
vector<int> edge[MAXN];
vector<int> e[MAXN];
int parent[MAXN];
int x[MAXN][MAXN];
int y[MAXN][MAXN];
int z[MAXN][MAXN];
int n;
int max1[MAXN],max2[MAXN];
int sum[MAXN];
int done[MAXN];
void init(){
	for(int i=0;i<n;i++)
		for(int j=0;j<edge[i].size();j++)
			x[i][edge[i][j]] = y[i][edge[i][j]] = z[i][edge[i][j]] =
			x[edge[i][j]][i] = y[edge[i][j]][i] = z[edge[i][j]][i] = -1;
}
void dfs(int u)
{
	done[u] = 1;
	for(int i=0;i<edge[u].size();i++) if(!done[edge[u][i]]){
		parent[edge[u][i]] = u;
		e[u].push_back(edge[u][i]);
		dfs(edge[u][i]);
	}
}
int calcx(int u,int v)
{
	if(x[u][v] != -1) return x[u][v];
	int & ret = x[u][v];
	ret = 1;
	for(int i=0;i<e[v].size();i++) if(e[v][i] != u){
		ret += calcx(v,e[v][i]);
	}
	return ret;
}
int calcy(int u,int v)
{
	if(y[u][v] != -1) return y[u][v];
	int & ret = y[u][v];
	ret = calcx(u,v);
	for(int i=0;i<e[v].size();i++) if(e[v][i] != u){
		ret += calcy(v,e[v][i]);
	}
	return ret;
}
int calcz(int u,int v)
{
	if(z[u][v] != -1) return z[u][v];
	int & ret = z[u][v];
	ret = calcx(u,v);
	int max = 0;
	for(int i=0;i<e[v].size();i++) if(e[v][i] != u)
		max >?= calcz(v,e[v][i]);
	ret += max;
	return ret;
}
int getDvalue(int u)
{
	int ret = 0;
	for(int i=0;i<edge[u].size();i++)
		ret += y[u][edge[u][i]];
	set<int> s;
	for(int i=0;i<edge[u].size();i++){
		s.insert(z[u][edge[u][i]]);
		if(s.size()>2){
			s.erase(s.begin());
		}
	}
	for(set<int>::iterator it = s.begin();it != s.end(); ++it)
		ret -= *it;
	return ret;
}
void update(int u)
{
	sum[u] = 0;
	for(int i=0;i<edge[u].size();i++)
		sum[u] += y[u][edge[u][i]];
	max1[u] = max2[u] = 0;
	for(int i=0;i<edge[u].size();i++){
		int c = z[u][edge[u][i]];
		if(c>max1[u]){
			max2[u] = max1[u];
			max1[u] = c;
		}
		else if(c>max2[u])
			max2[u] = c;
	}
}
void calc(int u,int v){
	calcx(u,v);
	calcy(u,v);
	calcz(u,v);
}
main()
{
	int cases;
	cin>>cases;
	while(cases--){
		scanf(" %d",&n);
		for(int i=0;i<n;i++){
			edge[i].clear();
			e[i].clear();
		}
		for(int i=1;i<n;i++){
			int j,k;
			scanf("%d %d",&j,&k);j--;k--;
			edge[j].push_back(k);
			edge[k].push_back(j);
		}
		init();
		for(int i=0;i<n;i++) done[i] = 0;
		dfs(0);
		for(int i=0;i<n;i++)
			for(int j=0;j<e[i].size();j++){
				calc(i,e[i][j]);
			}
		queue<int> qu;
		qu.push(0);
		while(!qu.empty()){
			int u = qu.front();
			qu.pop();
			for(int i=0;i<e[u].size();i++)
				qu.push(e[u][i]);
			if(u==0) {
				update(0);
				continue;
			}
			int v = parent[u];
			x[u][v] = n - x[v][u];
			y[u][v] = sum[v]-y[v][u]+x[u][v];
			z[u][v] = x[u][v] + (max1[v]==z[v][u]?max2[v]:max1[v]);
			update(u);
		}
		int ret = 100000000;
		for(int i=0;i<n;i++)
			ret <?= getDvalue(i);
		cout<<ret<<endl;
	}
}

