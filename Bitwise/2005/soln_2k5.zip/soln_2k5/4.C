/* None of the teams could submit a correct solution to this problem. Hence we are putting up our own solution.  */


#include <cstdio>
#include <iostream>
#include <set>
#include <vector>
#include <utility>
#include <cassert>
using namespace std;
#define Maxn 50000
int p[] = {5,13,17,29,37,41,53,61,73,89,97,101,109};
int a[] = {1,2,1,2,1,4,2,5,3,5,4,1,3};
int b[] = {2,3,4,5,6,5,7,6,8,8,9,10,10};
int pr[] =  {3,5,7,11,13,17,19,23,29,31,37,41,43,47,53};
vector<int> v;
int n;
long long int N;
class comp{
	public:
		long long int x, y;
		comp(long long int a,long long int b=0){
			x = a;
			y = b;
		}
};
comp operator*(comp a,comp b){
	return comp(a.x*b.x-a.y*b.y,a.x*b.y+a.y*b.x);
}
long long int x[20];
set<pair<long long int, long long int> > SET;
comp get(){
	comp ret(1);
	for(int i=0;i<v.size();i++){
		for(int j=0;j<x[i];j++){
			ret = ret*comp(a[i],b[i]);	
		}
		for(int j=x[i];j<v[i];j++){
			ret = ret*comp(a[i],-b[i]);
		}
	}
	ret.x = abs(ret.x);
	ret.y = abs(ret.y);
	return ret;
}
void go(int r){
	if(r==v.size()){
		comp factor = get();
		if(factor.x == 0 || factor.y == 0) return;
		SET.insert(make_pair(factor.x<?factor.y,factor.x>?factor.y));
		return;
	}
	for(int i=0;i<=v[r];i++){
		x[r] = i;
		go(r+1);
	}
}
main()
{
	int cases;
	cin>>cases;
	while(cases--){
		scanf("%d",&n);
		SET.clear();
		v.clear();
		N = 1;
		int temp = 2*n+1;
		for(int i=0;temp>1;i++){
			while(temp%pr[i]==0){
				v.push_back(pr[i]-1);
				temp /= pr[i];
			}
		}
		N = 1;
		reverse(v.begin(),v.end());
		for(int i=0;i<v.size();i++){
			for(int j=0;j<v[i]/2;j++)
				N *= p[i];
		}
		go(0);
		assert(SET.size()==n);
		cout<<N<<endl;
		for(set<pair<long long int,long long int> >::iterator it=SET.begin();
				it!=SET.end();++it){
			cout<<it->first<<endl;
		}
	}
}
