/* None of the teams could submit a correct solution to this problem. Hence we are putting up our own solution.  */

#include <cstdio>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cassert>
using namespace std;
#define MAXV 10001
#define DEBUG 0


int x[MAXV],y[MAXV];   //first co ordinates
int xx[MAXV],yy[MAXV]; //second co ordinates
double px[MAXV],py[MAXV]; //intersection points
int dx[MAXV],dy[MAXV]; //delta values for slope calculation.
int lex[MAXV];         //for sorting the lines on slopes.
int n;
vector<int> hull;
double eps = 1e-20;

// returns true if the slope of line i < slope of line j ,where both slopes are defined
// else, returns true or false assuming that the line parallel to Y-axis has +inf slope.
bool cmp(int i,int j){
	return dy[i]*dx[j] < dx[i]*dy[j];
}
// returns cross product
double crossp(double x1,double y1,double x2,double y2){
	return x1*y2-x2*y1;
}
// compute intersection of line l1 with line l2 (in the input order)
// and put this point in (px[i],py[i])
void compute_intersection_point(int l1,int l2,int i)
{
	double s = crossp(x[l2]-x[l1],y[l2]-y[l1],dx[l2],dy[l2]);
	s = s/crossp(dx[l1],dy[l1],dx[l2],dy[l2]);
	px[i] = x[l1] + s*(dx[l1]);
	py[i] = y[l1] + s*(dy[l1]);
}

//computes the intersection points of the pairs of lines, l and l+1 (in the sorted order)
void compute_intersection_points()
{
	int i,j,k;
	for(i=0;i<n;i++)
		lex[i] = i;
	sort(lex,lex+n,cmp); // sort the lines according to their slopes.
	lex[n] = lex[0]; //wrap around, for convenience.
	for(i=0;i<n;i++){
		compute_intersection_point(lex[i],lex[i+1],i);
	}	
}
bool cmp1(int i,int j){
	if(fabs(px[i]-px[j]) > eps) return px[i]<px[j];
	return py[i]<py[j]-eps;
}
double dist(int i,int j){
	return sqrt((px[i]-px[j])*(px[i]-px[j])+(py[i]-py[j])*(py[i]-py[j]));
}
bool rightturn(int i,int j,int k){
	double d1 = dist(k,j),d2 = dist(j,i);
	return crossp((px[k]-px[j])/d1,(py[k]-py[j])/d1,(px[j]-px[i])/d2,(py[j]-py[i])/d2)>eps;
}
void ConvexHull()
{
	hull.clear();
	vector<int> uhull,dhull;
	int i;
	for(i=0;i<n;i++) 
		lex[i] = i;
	sort(lex,lex+n,cmp1);
	uhull.push_back(lex[0]);
	uhull.push_back(lex[1]);
	for(i=2;i<n;i++){
		while(uhull.size()>1 && !rightturn(uhull[uhull.size()-2],uhull.back(),lex[i]))
			uhull.pop_back();
		uhull.push_back(lex[i]);
	}
	dhull.push_back(lex[n-1]);
	dhull.push_back(lex[n-2]);
	for(i=n-3;i>=0;i--){
		while(dhull.size()>1 && !rightturn(dhull[dhull.size()-2],dhull.back(),lex[i]))
			dhull.pop_back();
		dhull.push_back(lex[i]);
	}
	hull = uhull;
	hull.insert(hull.end(),dhull.begin()+1,dhull.end()-1);
}
double Area()
{
	int i;
	double ret = 0;
	hull.push_back(hull[0]);
	for(i=0;i<hull.size()-1;i++)
		ret += px[hull[i]]*py[hull[i+1]] - px[hull[i+1]]*py[hull[i]];
	return fabs(ret)/2;
}
main()
{
	int i;
	int cases;
	cin>>cases;
	while(cases--){
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d %d %d %d",&x[i],&y[i],&xx[i],&yy[i]);
			dx[i] = xx[i]-x[i];
			dy[i] = yy[i]-y[i];
			if(dx[i] < 0){
				swap(x[i],xx[i]);
				swap(y[i],yy[i]);
				dy[i] = -dy[i];
				dx[i] = -dx[i];
			}
			else if(dx[i]==0 && dy[i]<0){
				swap(y[i],yy[i]);
				dy[i] = -dy[i];
			}
		}
		compute_intersection_points();
		ConvexHull();
		double ans = Area();
//		printf("%.0f\n",floor(ans+0.5));
		printf("%.0f\n",floor(ans));
	}
}

