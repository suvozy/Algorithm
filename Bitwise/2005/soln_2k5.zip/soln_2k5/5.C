/* Many correct solutions were submitted, we are giving our solution as a sample.*/

#include <cstdio>
#include <iostream>
using namespace std;
int gcd(int a,int b){
	if(a>b) return gcd(b,a);
	return a==0?b:gcd(b%a,a);
}
main()
{
	int r,s,t;
	int cases;
	cin>>cases;
	while(cases--){
		scanf("%d %d %d",&r,&s,&t);
		int n;
		cout<<(long long int)r+s+t<<" ";
		printf("%d ",r+gcd(s,t));
		printf("%d ",gcd(r,s)+t);
		printf("%d ",gcd(r,s+t));
		printf("%d ",gcd(r+s,t));
		printf("%d\n",gcd(r+s,s+t));
	}
}
