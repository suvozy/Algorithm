/* This was the easiest prolem ,we got more than 100 correct submissions. We are giving you the solution submitted by "TheMightyReds" */

#include <iostream>
#include <stdio.h>
#include <vector>
#include <algorithm>
#include <map>
#include <string>
#include <cmath>
using namespace std;

int N;

void doit(int n, int to) {
	if (!n)
		return;
	doit(n-1,3-to);
	printf("0 %d\n",to);
	if (n<N)
		for (int i=1; i<n; i++)
			printf("%d %d\n",3-to,to);
}

void doit2(int n, int from) {
	if (!n)
		return;
	for (int i=1; i<n; i++)
		printf("%d %d\n",from,2-from);
	printf("%d 1\n",from);
	doit2(n-1,2-from);
}

int main() {
	int tc;
	scanf("%d",&tc);
	while(tc--) {
		int n;
		scanf("%d",&n);
		N = n;
		doit(n,1);
		doit2(n-1,2);
	}
	return 0;
}
