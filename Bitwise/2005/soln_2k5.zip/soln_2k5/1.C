/* We got only 7 correct submissions for this problem. This is our solution. */

#include <cstdio>
#include <iostream>

using namespace std;
#define MAXN 1002
#define MOD 100000000
long long int memo[MAXN][MAXN];
long long int doit(int n,int k){
	if(k>=n) return 0;
	if(k<0)  return 0;
	if(k==0) return n==1;
	long long int & ret = memo[n][k];
	if(ret != -1) return ret;
	return ret = (k*doit(n-1,k) + 2*doit(n-1,k-1) + (n-k)*doit(n-1,k-2))%MOD;
}
main()
{
	int n,k;
	memset(memo,-1,sizeof(memo));
	for(int i=1;i<=1000;i++)
		for(int j=1;j<i;j++)
			doit(i,j);
	int cases;
	cin>>cases;
	while(cases--){
		scanf("%d %d",&n,&k);
		cout<<doit(n,k)<<endl;
	}
}
