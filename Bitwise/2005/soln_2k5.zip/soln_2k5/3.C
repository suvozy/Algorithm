/* Quite a few teams submitted correct solution for this problem. This is our solution. */

#include <cstdio>
#include <iostream>
#include <cassert>
using namespace std;
#define MAXN 1001
#define MAXSLOTS 1000003

int p[MAXN],d[MAXN],q[MAXN];
int lex[MAXN];
bool cmp(int i,int j){
	if(p[i]!=p[j]) return p[i]>p[j];
	return d[i]>d[j];
}
int parent[MAXSLOTS];
int findset(int u){
	int v=u,temp;
	while(u != parent[u]) u = parent[u];
	while(v != u){
		temp = parent[v];
		parent[v] = u;
		v = temp;
	}
	return u;
}
void unite(int a){
	parent[a] = findset(a-1);
}
main()
{
	int n;
	int cases;
	cin>>cases;
	while(cases--){
		scanf("%d",&n);
		int max=0;
		for(int i=0;i<n;i++){
			scanf("%d %d %d",&p[i],&d[i],&q[i]);
			max >?= d[i];
		}

		for(int i=0;i<n;i++) lex[i] = i;
		sort(lex,lex+n,cmp);
		long long int ret = 0;
		for(int i=0;i<=max;i++) parent[i] = i;
		for(int i=0;i<n;i++)
			for(int j=0;j<q[lex[i]];j++)
			{
				int k = findset(d[lex[i]]);
				if(k!=0){
					unite(k);
					ret += p[lex[i]];
				}
				else break;
			}
		cout<<ret<<endl;
	}
}
