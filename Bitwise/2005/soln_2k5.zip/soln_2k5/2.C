/* This solution was submitted by TheMightyReds (University of Ulm) 
	Team Members: Robin Nittka and Adrian Kuegel */

#include <stdio.h>

long long S[1024][1024];
long long part[1024][1024] = {{0}};
const int mod = 100000000;


int main()
{
	int n, k, kases;
	for (n = 1; n <= 1000; n++)
		S[n][0] = 0;
	for (k = 0; k <= 1000; k++)
		S[0][k] = 0;
	S[0][0] = 1;
	for (n = 1; n <= 1000; n++)
		for (k = 1; k <= n; k++)
			S[n][k] = (S[n-1][k-1] + k*S[n-1][k]) % mod;

	scanf("%d", &kases);
	while (kases--)
	{
		scanf("%d%d", &n, &k);
		printf("%Ld\n", S[n][k]);
	}
	return 0;
}
