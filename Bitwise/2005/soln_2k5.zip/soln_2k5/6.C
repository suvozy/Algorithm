/* None of the teams could submit a fully correct solution to this problem. Hence we are putting up our own solution.  */

#include <cstdio>   
#include <iostream>   
#include <queue>   
#include <algorithm>   
#include <list>
using namespace std;

#define mp make_pair   
#define pb push_back   

#define fo(i,n) for(int i=0;i<n;++i)   
#define foreach(it,c) for(list<int>::iterator it =((c).begin());it != (c).end();++it)

/*
 *	Forget all directed edges except for noting valencies.
 * 	let v[i] = out[i]-in[i] (out[i] and in[i] are affected by only directed edges)
 * 	if(v[i]<0) add an edge of capacity -v[i] from source to i
 * 	else if(v[i]>0) add from i to sink with capacity v[i]
 * 	Max flow in this network should be equal to sum of positive valencies.
 * 	only then is this graph eulerian.
 */

int n,e;
list<int> edge[310];
int v[310],deg[310];
int c[310][310];
int done[310],p[310];
int augment(int s,int t)
{
	fo(i,n+2) done[i] = 0;
	done[s] = 1;
	queue<int> qu;
	qu.push(s);
	while(!qu.empty()){
		int u = qu.front();qu.pop();
		foreach(i,edge[u]){
			if(!done[*i] && c[u][*i]){
				done[*i] = c[u][*i]<?done[u];
				p[*i] = u;
				qu.push(*i);
			}
		}
		if(done[t]) break;
	}
	int ret = done[t];
	if(!ret) return 0;
	do{
		c[t][p[t]]+=ret;
		c[p[t]][t]-=ret;
		t = p[t];
	}while(t!=s);
	return ret;
}

int maxflow(int s,int t)
{
	int ret = 0;
	while(1){
		int now = augment(s,t);
		if(now==0) break;
		ret+= now;
	}
	return ret;
}
main()
{
	int cases;
	cin>>cases;
	while(cases--){
		scanf("%d %d",&n,&e);
		fo(i,n)edge[i].clear();
		fo(i,n)deg[i] = v[i] = 0;
		int i,j,d;
		fo(i,n)fo(j,n) c[i][j] = 0;
		bool bad=false;		
		while(e--){
			scanf("%d %d %d",&i,&j,&d);i--;j--;
			if(i==j) continue;	
			deg[i]++;deg[j]++;
			if(!d)edge[i].pb(j);
			if(!d)edge[j].pb(i);
			if(!d) c[i][j]++;
			if(!d) c[j][i]++;
			if(d) {v[i]++;v[j]--;}
		}
		fo(i,n) if(deg[i]%2){
			bad = true;
			break;
		}
		if(bad){
			printf("No\n");continue;
		}
		int s=n,t=n+1;
		edge[s].clear();edge[t].clear();
		fo(i,n){
			if(v[i]<0){
				edge[s].pb(i);
				c[s][i] = -v[i];
			}else if(v[i]>0){
				edge[i].pb(t);
				c[i][t] = v[i];
			}
		}
		int req=0;
		fo(i,n) if(v[i]>0) req += v[i];
		int ret = maxflow(s,t);
		if(ret==req) printf("Yes\n");
		else {
			printf("No\n");
		}
	}
}
